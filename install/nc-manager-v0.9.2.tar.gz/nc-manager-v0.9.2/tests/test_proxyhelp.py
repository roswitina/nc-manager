# Nextcloud Server Manager
# Copyright (c) 2026 roswitina@hotmail.com
# SPDX-License-Identifier: MIT
# Lizenz: siehe LICENSE · Gewährleistungs- und Haftungsausschluss: siehe HAFTUNGSAUSSCHLUSS.md
"""Tests des Reverse-Proxy-Assistenten (reine Berechnung) und – auf Wunsch – Syntaxprüfung mit echten Proxys."""
import os
import shutil
import subprocess
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import proxyhelp as ph  # noqa: E402

# Bewährte DietPi-Einstellungen (Nextcloud unter /nextcloud hinter Nginx Proxy Manager)
DIETPI_CFG = {'trusted_domains': ['localhost', 'files.domain.tld', 'files.home.arpa', '192.168.1.55', '192.168.1.198'],
              'overwritehost': 'files.domain.tld', 'overwriteprotocol': 'https', 'overwritewebroot': '/nextcloud',
              'overwritecondaddr': '^192\\.168\\.1\\.198$', 'trusted_proxies': ['192.168.1.198'],
              'overwrite.cli.url': 'https://files.domain.tld'}


def make(public='https://files.domain.tld', internal='http://192.168.1.55/nextcloud', proxy='192.168.1.198', kind='npm',
         root_alias=True, cfg=None):
    v, errors = ph.parse_inputs(public, internal, proxy, kind, root_alias)
    assert not errors, errors
    return ph.plan(v, cfg or {})


def by_key(r):
    return {s['key']: s for s in r['settings']}


def test_dietpi_setup_is_recognised_as_complete():
    r = make(cfg=DIETPI_CFG)
    assert r['missing'] == 0 and r['warnings'] == []
    assert r['public_base'] == 'https://files.domain.tld/nextcloud'
    npm = r['snippets']['npm']['config']
    for line in ('location /nextcloud/ {', 'proxy_pass http://192.168.1.55/nextcloud/;', 'location = / {',
                 'return 301 https://$host/nextcloud/remote.php/dav/;', 'location ^~ /remote.php {',
                 'proxy_pass http://192.168.1.55/nextcloud/status.php;', 'proxy_set_header X-Forwarded-Proto https;',
                 'proxy_set_header Upgrade $http_upgrade;'):
        assert line in npm, line
    assert [t for t, _ in r['snippets']['npm']['steps']] == ['Details', 'Custom locations', 'SSL', 'Advanced']


def test_overwrite_cli_url_with_or_without_path():
    cfg = dict(DIETPI_CFG)
    assert by_key(make(cfg=cfg))['overwrite.cli.url']['ok']                       # ohne /nextcloud dank Wurzel-Endpunkten
    assert not by_key(make(cfg=cfg, root_alias=False))['overwrite.cli.url']['ok']  # ohne Wurzel-Endpunkte: Pfad nötig
    cfg['overwrite.cli.url'] = 'https://files.domain.tld/nextcloud/'
    assert by_key(make(cfg=cfg, root_alias=False))['overwrite.cli.url']['ok']


def test_missing_settings_and_commands():
    r = make(cfg={'trusted_domains': ['localhost', '192.168.1.55']})
    s = by_key(r)
    assert not s['trusted_domains']['ok'] and s['trusted_domains']['cmd'] == 'config:system:set trusted_domains 2 --value=files.domain.tld'
    assert s['trusted_proxies']['cmd'] == 'config:system:set trusted_proxies 0 --value=192.168.1.198'
    assert s['overwritecondaddr']['cmd'] == "config:system:set overwritecondaddr --value='^192\\.168\\.1\\.198$'"
    assert r['missing'] == 7


def test_root_and_port_installations():
    r = make(internal='http://192.168.1.55', root_alias=False)
    assert 'overwritewebroot' not in by_key(r) and r['public_base'] == 'https://files.domain.tld'
    assert 'location / {' in r['snippets']['nginx']['config'] and 'location = / {' not in r['snippets']['nginx']['config']
    r = make(internal='http://192.168.1.55:12345', root_alias=False, kind='caddy')
    assert 'reverse_proxy 192.168.1.55:12345' in r['snippets']['caddy']['config']
    assert 'Forward Port: 12345' in r['snippets']['npm']['steps'][0][1]
    r = make(public='https://files.domain.tld:8443')
    assert by_key(r)['overwritehost']['value'] == 'files.domain.tld:8443'
    assert 'https://$http_host/nextcloud/remote.php/dav/' in r['snippets']['npm']['config']   # Port bleibt erhalten


def test_warnings_and_network_proxy():
    r = make(public='https://files.domain.tld/cloud')
    assert any('unterscheiden sich' in w for w in r['warnings']) and r['public_base'] == 'https://files.domain.tld/nextcloud'
    assert any('https://' in w for w in make(public='http://files.domain.tld')['warnings'])
    r = make(proxy='192.168.1.0/24')
    assert 'overwritecondaddr' not in by_key(r) and any('ganzes Netz' in n for n in r['notes'])
    assert make(internal='https://192.168.1.55/nextcloud', kind='apache')['snippets']['apache']['config'].count('SSLProxyEngine on') == 1


@pytest.mark.parametrize('args,msg', [
    (('nc.domain.tld', 'http://1.2.3.4', '1.2.3.5', 'npm'), 'Öffentliche Adresse'),
    (('https://nc.domain.tld', 'ftp://1.2.3.4', '1.2.3.5', 'npm'), 'Interne Adresse'),
    (('https://nc.domain.tld', 'http://1.2.3.4', 'proxy', 'npm'), 'IP des Proxys'),
    (('https://nc.domain.tld', 'http://1.2.3.4', '1.2.3.5', 'traefik'), 'Proxy-Programm'),
    (('https://nc.domain.tld;rm -rf /', 'http://1.2.3.4', '1.2.3.5', 'npm'), 'Öffentliche Adresse'),
])
def test_invalid_inputs(args, msg):
    v, errors = ph.parse_inputs(*args, root_alias=False)
    assert v is None and any(msg in e for e in errors)


# Syntaxprüfung mit echten Proxys – schreibt nach /etc, deshalb nur mit NCM_TEST_WEBSERVER=1 (Testsystem)
REAL = os.environ.get('NCM_TEST_WEBSERVER') == '1' and os.geteuid() == 0


@pytest.mark.skipif(not (REAL and shutil.which('nginx')), reason='NCM_TEST_WEBSERVER=1 und nginx nötig')
@pytest.mark.parametrize('internal', ['http://192.168.1.55/nextcloud', 'http://192.168.1.55', 'http://192.168.1.55:12345'])
def test_nginx_and_npm_syntax(internal, tmp_path):
    r = make(internal=internal, kind='nginx')
    conf = r['snippets']['nginx']['config']
    conf = conf.replace('listen 80;', 'listen 19091;').replace('    listen [::]:80;\n', '').replace('listen 443 ssl;', 'listen 19455;')
    conf = conf.replace('    listen [::]:443 ssl;\n', '').replace('    http2 on;', '')
    conf = '\n'.join(ln for ln in conf.splitlines() if 'ssl_certificate' not in ln)
    conf += f"\nserver {{ listen 19458; server_name x;\n{r['snippets']['npm']['config']}\n}}\n"
    site = '/etc/nginx/sites-enabled/ncm-proxytest'
    try:
        open(site, 'w').write(conf)
        res = subprocess.run(['nginx', '-t'], capture_output=True, text=True)
        assert res.returncode == 0, res.stderr
    finally:
        os.unlink(site)


@pytest.mark.skipif(not (REAL and shutil.which('caddy')), reason='NCM_TEST_WEBSERVER=1 und caddy nötig')
def test_caddy_syntax(tmp_path):
    f = tmp_path / 'Caddyfile'
    f.write_text(make(kind='caddy')['snippets']['caddy']['config'])
    res = subprocess.run(['caddy', 'validate', '--adapter', 'caddyfile', '--config', str(f)], capture_output=True, text=True)
    assert res.returncode == 0, res.stderr[-500:]
